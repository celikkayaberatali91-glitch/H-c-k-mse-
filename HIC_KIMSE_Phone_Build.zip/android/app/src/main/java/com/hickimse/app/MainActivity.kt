package com.hickimse.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private val BACKEND_URL = BuildConfig.BACKEND_URL
    private val speechRequestCode = 41
    private lateinit var status: TextView
    private lateinit var transcript: TextView
    private lateinit var input: EditText
    private lateinit var sendButton: Button
    private lateinit var micButton: Button
    private lateinit var tts: TextToSpeech
    private val history = JSONArray()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 30, 28, 20)
            setBackgroundColor(0xFF0B1220.toInt())
        }
        val title = TextView(this).apply {
            text = "HİÇ KİMSE"
            textSize = 28f
            setTextColor(0xFF63E6FF.toInt())
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Hazırım kanka. Yaz ya da mikrofona bas."
            textSize = 14f
            setTextColor(0xFFCBD5E1.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 14)
        }
        transcript = TextView(this).apply {
            text = "HİÇ KİMSE: Buradayım kanka. Ne yapıyoruz?"
            textSize = 17f
            setTextColor(0xFFF8FAFC.toInt())
            setPadding(0, 12, 0, 12)
        }
        val scroll = ScrollView(this).apply { addView(transcript) }
        input = EditText(this).apply {
            hint = "Bir şey sor kanka..."
            setHintTextColor(0xFF94A3B8.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            setSingleLine(false)
            minLines = 2
            setPadding(16, 12, 16, 12)
            setBackgroundColor(0xFF1E293B.toInt())
        }
        micButton = Button(this).apply {
            text = "🎙 Konuş"
            setOnClickListener { startSpeechRecognition() }
        }
        sendButton = Button(this).apply {
            text = "Gönder"
            setOnClickListener { sendMessage(input.text.toString().trim()) }
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(status, LinearLayout.LayoutParams(-1, -2))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(input, LinearLayout.LayoutParams(-1, -2))
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(micButton, LinearLayout.LayoutParams(0, -2, 1f))
            addView(sendButton, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(buttons, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    private fun startSpeechRecognition() {
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Seni dinliyorum kanka...")
            }
            startActivityForResult(intent, speechRequestCode)
        } catch (_: Exception) {
            status.text = "Kanka, bu telefonda konuşma tanıma hizmeti bulunamadı."
        }
    }

    @Deprecated("Uses the standard Android speech recognition activity")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == speechRequestCode && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            if (spoken.isNotBlank()) {
                input.setText(spoken)
                sendMessage(spoken)
            }
        }
    }

    private fun sendMessage(message: String) {
        if (message.isBlank()) return
        if (BACKEND_URL.contains("YOUR-HTTPS-BACKEND")) {
            status.text = "Sunucu kurulumu gerekiyor kanka. APK şu an sohbet sunucusuna bağlı değil."
            return
        }
        input.setText("")
        appendLine("Sen", message)
        history.put(JSONObject().put("role", "user").put("content", message))
        status.text = "Düşünüyorum kanka..."
        sendButton.isEnabled = false
        micButton.isEnabled = false

        thread {
            var answer = ""
            var error: String? = null
            try {
                val connection = (URL(BACKEND_URL).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 20000
                    readTimeout = 60000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
                val payload = JSONObject().put("messages", history)
                connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val body = stream.bufferedReader().use { it.readText() }
                connection.disconnect()
                if (code !in 200..299) throw Exception("Sunucu HTTP $code")
                answer = JSONObject(body).optString("reply", "")
                if (answer.isBlank()) throw Exception("Sunucudan boş yanıt geldi.")
                history.put(JSONObject().put("role", "assistant").put("content", answer))
            } catch (e: Exception) {
                error = e.message ?: "Bağlantı hatası"
            }
            runOnUiThread {
                sendButton.isEnabled = true
                micButton.isEnabled = true
                if (error != null) {
                    status.text = "Bağlantı sorunu: $error"
                } else {
                    appendLine("HİÇ KİMSE", answer)
                    status.text = "Buradayım kanka."
                    tts.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "hic-kimse-reply")
                }
            }
        }
    }

    private fun appendLine(who: String, message: String) {
        transcript.append("\n\n$who: $message")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale("tr", "TR"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                if (::status.isInitialized) status.text = "Türkçe ses paketi telefonda eksik olabilir."
            }
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }
}
