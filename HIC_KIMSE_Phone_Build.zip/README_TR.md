# HİÇ KİMSE — Android başlangıç projesi

Bu paket, yalnızca Android telefon kullanarak GitHub üzerinden APK derlemeyi kolaylaştırmak için hazırlanmıştır.

## Önemli
- Bu ZIP **APK değildir**; kaynak kodudur.
- GitHub Actions APK'yı bulutta derleyebilir.
- Yapay zekâ cevaplarının çalışması için ayrıca `server/` klasöründeki Node.js sunucusunu HTTPS destekleyen bir sunucuya dağıtmanız ve `OPENAI_API_KEY` ortam değişkenini ayarlamanız gerekir.
- API anahtarını Android uygulamasına koymayın.
- Kod burada derlenip gerçek telefonda test edilmiş değildir.

## APK'yı telefonla oluşturma
1. ZIP'i çıkarın ve içindeki dosyaları GitHub'da yeni bir depoya yükleyin.
2. Depoda **Actions** sekmesini açın. GitHub Actions için izin istenirse etkinleştirin.
3. `Build Android APK` iş akışını çalıştırın veya dosyaları yükledikten sonra otomatik çalışmasını bekleyin.
4. İş akışı başarılı olursa çalıştırma sayfasının altındaki **Artifacts** bölümünden `hic-kimse-debug-apk` dosyasını indirin.
5. ZIP içinden `app-debug.apk` dosyasını çıkarıp Android telefonunuza kurun.

## Yapay zekâ sunucusu
1. `server/` içeriğini Node.js destekleyen bir barındırma servisine dağıtın.
2. Sunucu ortam değişkeni `OPENAI_API_KEY` olarak kendi API anahtarınızı ekleyin.
3. `server/index.js` içinde model varsayılanı `gpt-4o-mini` olarak ayarlanmıştır; servis hesabınızın desteklediği modeli kullanın.
4. Dağıtım adresinizin HTTPS olduğundan emin olun.
5. Android'de `android/app/build.gradle` dosyasındaki `BACKEND_URL` sabitini `https://SENIN-SUNUCUN/chat` biçiminde güncelleyin ve yeni APK derleyin.

API kullanımı ücret doğurabilir. Anahtarınızı kimseyle paylaşmayın.
