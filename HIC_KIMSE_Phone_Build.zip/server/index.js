import express from "express";
import OpenAI from "openai";

const app = express();
app.use(express.json({ limit: "1mb" }));

const apiKey = process.env.OPENAI_API_KEY;
const client = apiKey ? new OpenAI({ apiKey }) : null;
const model = process.env.MODEL || "gpt-4o-mini";

app.get("/", (_req, res) => res.json({ name: "HİÇ KİMSE", status: "ok" }));

app.post("/chat", async (req, res) => {
  try {
    if (!client) return res.status(503).json({ error: "Sunucu OPENAI_API_KEY ayarlanmamış." });
    const incoming = Array.isArray(req.body?.messages) ? req.body.messages : [];
    const messages = incoming
      .filter(m => m && ["user", "assistant"].includes(m.role) && typeof m.content === "string")
      .slice(-30)
      .map(m => ({ role: m.role, content: m.content.slice(0, 8000) }));

    if (!messages.length) return res.status(400).json({ error: "Mesaj bulunamadı." });

    const response = await client.chat.completions.create({
      model,
      messages: [
        {
          role: "system",
          content: "Senin adın HİÇ KİMSE. Türkçe konuşan, samimi, saygılı, güvenilir bir kanka gibi davran. Kısa ve doğal cevap ver. Kullanıcıya Berat diye hitap etmek zorunda değilsin. Emin olmadığın şeyleri uydurma. Sağlık, hukuk ve güvenlik konularında kesin hüküm verme."
        },
        ...messages
      ],
      temperature: 0.8
    });
    res.json({ reply: response.choices?.[0]?.message?.content || "Kanka, bir daha dener misin?" });
  } catch (error) {
    console.error("chat error:", error?.message || error);
    res.status(500).json({ error: "Yanıt oluşturulamadı. Sunucu ayarlarını kontrol edin." });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`HİÇ KİMSE server listening on ${port}`));
